const STARTDIALOG = 'STARTDIALOG',  GETMESSAGE = 'GETMESSAGE',
SENDMESSAGE='SENDMESSAGE',DELETEMESSAGE='DELETEMESSAGE',GOTDIALOGS='GOTDIALOGS'

const defaultstate= {
        dialogs:[],
        messages:[]
    }
  
    export default function dialogsReducer(state = defaultstate, action){
    let newState = { ...state };
    switch (action.type)
    {

        case STARTDIALOG:

            return newState
         case GOTDIALOGS:
           newState.dialogs=[...action.dialogs]
            console.log('GOTDIALOGS')
            console.log(action.dialogs)
            return newState

        case SENDMESSAGE:
           newState.messages.unshift(action.message)
            
            return newState

        case DELETEMESSAGE:
         //  newState.messages.
            
            return newState
        
        
        default: return state
    }
}

export const startDialog = (user) => { return { user, type: STARTDIALOG } }
export const onGetMessages = (messages) => { return { messages, type: GETMESSAGE } }  
export const onSendMessage = (message) => { return { message, type: SENDMESSAGE } }  
export const onDeleteMessageById = (id) => { return { id,  type: DELETEMESSAGE } }  
export const onGetDialogs = (dialogs) => { return { dialogs, type: GOTDIALOGS } }  
