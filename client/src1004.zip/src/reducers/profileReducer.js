const ADDPOSTS='ADDPOSTS', DELETEPOSTBYID='DELETEPOSTBYID',
    GETPROFILE = 'GETPROFILE', GETPOSTS = 'GETPOSTS', GETPHOTOS = 'GETPHOTOS', DELETEPHOTOBYID = 'DELETEPHOTOBYID',
ADDPHOTO='ADDPHOTO'

const defaultstate = {
    posts: [
        {
            _id: 123, user: '111', date: 'дата', postTitle:'Название поста',postBody: `Установлено, что в 2015 году с возглавляемой им коммерческой структурой был заключен договор подряда на выполнение работ по строительству складских сооружений, возводимых в интересах одного из государственных заказчиков на территории Камчатского края. В качестве аванса на расчетный счет организации было перечислено более 700 млн рублей.

Однако подрядчик взятые на себя обязательства не исполнил и строительно-монтажные работы не выполнил. Полученные денежные средства были похищены путем вывода на расчетные счета сторонних организаций.

В ходе расследования уголовного дела сотрудниками Следственного департамента МВД России совместно с сотрудниками ГУЭБиПК МВД России, ГУ МВД России по г. Москве, ГУ МВД России по г. Санкт-Петербургу и Ленинградской области при силовой поддержке сотрудников Росгвардии проведено 19 обысков на территории трех субъектов Российской Федерации. Обнаружены и изъяты финансово-хозяйственные документы, средства связи, компьютерная техника, электронные носители информации, имеющие доказательственное значение. `,postImageSrc:'https://static.mvd.ru/upload/site1/document_news/Kaliningrad-630xx225.jpg?rnd=0.4784786219426467'},
       {_id:1234,user:'111',date:'дата',postBody:'Пост 2',postImageSrc:'https://static.mvd.ru/upload/site1/document_news/kortes_slayder-630xx225.jpg?rnd=0.6640405809844421'}
    ],
        photos:[],
    status: 'Default status1',
    publicName:'publicName1', //- чьи данные профиля загружены
    livingPlace:'livingPlace1',
    profileImageSrc:'',
    date:'',
    postsIsFetching: false,
    profileIsFetching: false,
    profileId:null

            
    }
  
const profileReducer=(state = defaultstate, action)=>{
    let newState = { ...state };
    switch (action.type)
    {
        case GETPOSTS:
           
            action.posts?    
        newState.posts=[...action.posts]:newState.posts=[]
       // console.log('added posts:'+newState.posts)
            return newState 
        case ADDPOSTS:
          //  console.log('reducer posts='+action.posts.postBody)
            newState.posts=[action.posts,...state.posts]
            return newState

        case DELETEPOSTBYID:
            
            
            break
        case GETPHOTOS:
            newState.photos=[action.photos,...state.photos]
            return newState   
        case ADDPHOTO:
            newState.photos=[action.photo,...state.photos]
            return newState 
        case DELETEPHOTOBYID:
                    let id = action.id
                    const index = newState.photos.findIndex(item => item._id === id)
                    const before = newState.photos.slice(0, index)
                    const after = newState.photos.slice(index + 1)
                    const newArr = [...before, ...after]
                    newState.photos = newArr
            return newState
        case GETPROFILE:
            //console.log(action)
            newState.status = action.profile.status
            newState.livingPlace = action.profile.livingPlace
            newState.profileImageSrc = action.profile.profileImageSrc
            newState.date = action.profile.date
            newState.publicName=action.profile.publicName
            newState.profileId=action.profile._id
         //  console.log('reducer profileId='+action.profile._id)
            return newState

        default: return state
    }
}

export const onAddPosts = (posts) => { return { posts, type: ADDPOSTS } }
export const onGetPosts = (posts) => { return { posts, type: GETPOSTS } }
export const onGetPhoto = (photos) => { return { photos, type: GETPHOTOS } }
export const onGetProfile = (profile) => { return { profile, type: GETPROFILE } }
export const onAddPhoto = (photo) => { return { photo, type: ADDPHOTO } }

export const onDeletePostById = (id) => { return { id, type: DELETEPOSTBYID } }
export const onDeletePhotoById = (id) => { return { id, type: DELETEPHOTOBYID } }


export default profileReducer