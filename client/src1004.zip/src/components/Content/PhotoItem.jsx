import s from './PhotoItem.module.css';
import React from 'react'


export class PhotoItem extends React.PureComponent{
  render = () => {
    const divStyle = {
      color: 'blue',
      backgroundImage: 'url(' + this.props.photoImageSrc + ')',
    };
    return (
      <div className={s.photo} style={divStyle}> 
    </div>
  )}
}