import React from 'react'
import ShowProfile from './ShowProfile';
import { onSelectedUser } from '../../reducers/usersReducer'
import { getSelectedUserProfileByUserId, getSelectedUserPostsByUserId, getSelectedUserPhotoByUserId } from '../../utils/API/connectSelectedProfile'
import {userMessageSend } from '../../utils/API/connectDialogs'
import { connect } from 'react-redux'
import Post from '../Profile/Post'
import PhotoPreview from './PhotoPreview'
import SendMessage from './SendMessage';

class UserById extends React.Component{
 
  componentDidMount() {
    // this.userId = this.props.match.params.userId;
    // this.props.onSelectedUser(this.userId)
    // console.log('selectedUser='+this.props.selectedUserProfile.publicName)
    this.props.getSelectedUserProfileByUserId(this.props.selectedUser)
    this.props.getSelectedUserPostsByUserId(this.props.selectedUser)
    this.props.getSelectedUserPhotoByUserId(this.props.selectedUser)
    
  }
  
  componentDidUpdate(prevProps) {
    //console.log('selectedUser='+this.props.selectedUserProfile.publicName)
    
    if (this.props.selectedUserProfileId !== prevProps.selectedUserProfileId)
      {
        this.props.getSelectedUserProfileByUserId(this.props.selectedUser)
        this.props.getSelectedUserPostsByUserId(this.props.selectedUser)
        this.props.getSelectedUserPhotoByUserId(this.props.selectedUser)
      }
  }
 
  render() {
    //console.log('this.props.selectedUserPhotos='+this.props.selectedUserPhotos)
    this.userId = this.props.match.params.userId;
    this.props.onSelectedUser(this.userId)
        let post=[]
     post = this.props.selectedUserPosts.map(item => {
       return (<li key={item._id}><Post _id={item._id } date={item.date} postBody={item.postBody}
        postImageSrc={item.postImageSrc} user={this.props.selectedUserProfile.publicName }/></li>)
     })
    let userId=this.props.selectedUser?this.props.selectedUser._id:''
    return <div><ShowProfile selectedUserProfile={this.props.selectedUserProfile} />
      <SendMessage  userMessageSend={this.props.userMessageSend} userId={this.props.selectedUser}/>
      
      {this.props.selectedUserPhotos.length?<PhotoPreview photos={ this.props.selectedUserPhotos}/>:''}
    { post }
    </div>
  }
}


 const mapStateToProps = (state) => {
    return {
      selectedUser: state.usersPage.selectedUser,
      selectedUserPhotos: state.usersPage.selectedUserPhotos,
      selectedUserProfile:state.usersPage.selectedUserProfile,
    selectedUserPosts: state.usersPage.selectedUserPosts,
    
    }
  }
        

  
const UserByIdContainer = connect(mapStateToProps, {
  onSelectedUser, getSelectedUserProfileByUserId, getSelectedUserPostsByUserId,
  getSelectedUserPhotoByUserId,userMessageSend})(UserById);




export default UserByIdContainer;

