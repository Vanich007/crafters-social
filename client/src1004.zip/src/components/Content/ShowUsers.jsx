import s from './ShowUsers.module.css';
import React from 'react'


class ShowUsers extends React.Component{
 
  // constructor(props) {
  //   super(props)
  // //this.props.delUser=this.props.delUser.bind(this)
 
  // }
   
  render = () => {
    return (
      <a href={process.env.PUBLIC_URL+this.props.userId}><div className={s.userwrapper}>
      <div className={s.user}>
      <img src={process.env.PUBLIC_URL + '/images/guestavatar.gif'} className={s.avatar}></img>
      <span className={s.name} >{this.props.publicName}</span>
      <span className={s.klass}>{this.props.status}</span>
      <span className={s.klass}>{this.props.livingPlace}</span>
      <span className={s.klass}>{this.props.date}</span>
      
        
        </div></div></a>
    
  );
    
  }
}


export default ShowUsers;