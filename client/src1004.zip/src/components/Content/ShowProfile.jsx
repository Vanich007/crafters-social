import React, {useState,useEffect} from 'react';
import s from './ShowProfile.module.css'



export default function ProfileAnketa({selectedUserProfile }) {

  return (<div className={s.anketablock}>
    
    {(selectedUserProfile.profileImageSrc)?<img src={selectedUserProfile.profileImageSrc}></img>:''}
    
     <div className={s.line} >
      <label>Статус </label><b>{selectedUserProfile.status}</b></div>
      <div className={s.line} ><label>Место жительства </label><b>{selectedUserProfile.livingPlace}</b></div>
      <div className={s.line} ><label>Имя пользователя </label><b>{selectedUserProfile.publicName}</b></div>
    </div>
    )
  
}