import s from './Footer.module.css';


function Footer(props) {
  return (
      <div className={s.footer}>
      Footer
    </div>
  );
}

export default Footer;