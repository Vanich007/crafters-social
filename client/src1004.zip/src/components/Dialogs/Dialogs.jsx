import {PureComponent} from 'react'
import { connect } from 'react-redux'
import {getDialogsByUserId} from '../../utils/API/connectDialogs'
import {onGetDialogs} from '../../reducers/dialogsReducer'

class Dialogs extends PureComponent {
    componentDidMount() {
        this.props.getDialogsByUserId()
}
componentDidUpdate(prevProps) {
    if (this.props.currentUser._id)
    if(this.props.currentUser._id!==prevProps.currentUser._id){
        this.props.getDialogsByUserId()
    }}
    render(){
        
    let dialogs = this.props.dialogs.map(item => {
        return (
            <li key={item._id}><DialogItem message={item.lastMessage}/></li>
        )
    })

    return (<div>
        {dialogs}

    </div>)
}}
const DialogItem=(props)=>{
    console.log('dialogItem=',props.message)
    return <div>
        {props.message.messageBody}
    </div>
}

const mapStateToProps = (state) => {
    return {
        currentUser: state.signupPage.currentUser,
      dialogs: state.dialogsPage.dialogs
    }
  }
        
 
const DialogsContainer = connect(mapStateToProps,
     {onGetDialogs,getDialogsByUserId})(Dialogs);

export default DialogsContainer;