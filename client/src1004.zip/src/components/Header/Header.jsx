import React from 'react'
import { Link } from 'react-router-dom'
import s from './Header.module.css';


function Header(props) {
  return (<>
      <header id="header">
      <div class="container">
        

          <div class="btn-toolbar btn-group-sm pull-right">
            
            
            
            <a href="http://szfo.sed.mvd.ru" class="btn btn-primary preloader-link" title="Рабочее место делопроизводителя">
              <span class="glyphicon glyphicon-share-alt"></span>
</a>
            <a href="/" class="btn btn-primary preloader-link" data-remote="true" title="Домой">
              <span class="glyphicon glyphicon-home"></span>
</a>
            <a href="/documents?is_registered=true" class="btn btn-primary preloader-link" data-remote="true" title="Зарегистрированные">
              <span class="glyphicon glyphicon-align-justify"></span>
</a>
            <a href="/documents?folder_id=56eaa1608e8500000a000001" class="btn btn-primary preloader-link" data-remote="true" title="Избранное">
              <span class="glyphicon glyphicon-star"></span>
</a>
            <a href="/documents?folder_id=56eaa1608e8500000b000001" class="btn btn-primary preloader-link" data-remote="true" title="Обработанные">
              <span class="glyphicon glyphicon-wrench"></span>
</a>
            <a href="/documents?on_route=true" class="btn btn-primary preloader-link" data-remote="true" title="Отправленные по маршруту">
              <span class="glyphicon glyphicon-sort"></span>
</a>
            <a href="/activities" class="btn btn-primary preloader-link" data-remote="true" title="Активность профиля">
              <span class="glyphicon glyphicon-time"></span>
</a>
            <a href="/events" class="btn btn-primary preloader-link" data-remote="true" id="events_button" title="Календарь событий">
              <span class="glyphicon glyphicon-calendar"></span>
</a>
            <a href="/settings" class="btn btn-primary preloader-link" data-remote="true" title="Настройки">
              <span class="glyphicon glyphicon-cog"></span>
</a>          
            <div class="btn-group btn-group-sm">
              <a href="/colleagues/to_another_provider" class="btn btn-primary" data-method="put" data-remote="true" data-toggle="dropdown" rel="nofollow">
                Пользователь: <strong>Vanich007</strong>
</a>           
              <a href="/common/saml/destroy_session" class="btn btn-primary" data-method="post" rel="nofollow"><span class="glyphicon glyphicon-log-out" title="Выход"></span></a>
            </div>

          </div>

        

        <a href="#nav" class="btn btn-primary btn-sm pull-right collapsed" data-toggle="collapse"><span class="glyphicon glyphicon-menu-hamburger"></span></a>
        <a href="/" id="logo"></a>
        <h1>CraftTerritory</h1>
      </div>


    </header>
       <div class="menu-container">
  <nav>
    <ul>
      <li><Link to='/users/'>В ленту</Link></li>
      <li><Link to='/profile/'>Профиль</Link></li>
      <li><Link to='/profile/'>Проекты</Link></li>
      <li><Link to='/users/'>Пользователи</Link></li>
    </ul>
  </nav>
</div>
    </>
  );
}

export default Header;