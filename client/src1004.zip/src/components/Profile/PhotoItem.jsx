import s from './Post.module.css';
import React from 'react'


export default class PhotoItem extends React.PureComponent{
  
  
   
  render = () => {
  
    return (
      <div className={s.wrapper}>
        
        
        <div className={s.date}>{this.props.date}</div>  
        <div className={s.photo} ><img src={this.props.photoImageSrc} className={s.post_img}></img></div>
        <button onClick={()=>this.props.deleteItem}>Delete</button>
          
          <div className={s.post_body} >{this.props.photoText}</div>
       
      </div>
    
  );
    
  }
}