import React from 'react'
import s from './Profile.module.css';
import { onAddPosts,onDeletePostById } from '../../reducers/profileReducer'
import {getProfileFetch} from '../../reducers/signupReducer'
import { connect } from 'react-redux'
import { getPostsByUserId } from '../../utils/API/connectPosts'
import { getProfileByUserId } from '../../utils/API/connectProfile' 
import {getPhotoByUserId} from '../../utils/API/connectPhoto'
//import Preloader from '../../utils/preloader'
import Post from './Post'
import AddPostContainer from './AddPost'
import ProfileAnketaContainer from './ProfileAnketa'


class Profile extends React.PureComponent{
 postsIsFetching:false
  componentDidMount() {
    // if (!this.props.match.params.userId) {
    this.postsIsFetching=true  
    this.props.getProfileFetch()
    if(this.props.currentUser._id){
    this.props.getProfileByUserId(this.props.currentUser._id) 
    this.props.getPostsByUserId(this.props.currentUser._id) 
    this.props.getPhotoByUserId(this.props.currentUser._id) }
    this.postsIsFetching=false
    // } else getPostsByUserId(this.props.match.params.userId)
    
  }
  
  componentDidUpdate(prevProps) {
    if (this.props.currentUser._id)
    if(this.props.currentUser._id!==prevProps.currentUser._id){
      this.props.getProfileByUserId(this.props.currentUser._id) 
      this.props.getPostsByUserId(this.props.currentUser._id) 
      this.props.getPhotoByUserId(this.props.currentUser._id) 
    } 
    // if ((this.props.userId !== prevProps.userId)||(this.props.match.params.userId!==prevProps.match.params.userId))
    // {this.props.getProfileByUserId(this.props.currentUser._id) 
    // this.props.getPostsByUserId(this.props.currentUser._id) }
  }

  render() {
    //console.log('profileId='+this.props.profileId+'current='+this.props.currentUser._id)
    let post=[]
    if (!this.postsIsFetching) post = this.props.posts.map(item => {
      return <li key={item._id}><Post id={item._id} date={item.date} postTitle={item.postTitle} postBody={item.postBody}
        postImageSrc={item.postImageSrc} user={this.props.publicName } profileImageSrc={this.props.profileImageSrc}/></li>
    })
    return (<div><h1>Профиль пользователя {this.props.publicName}</h1>
      <ProfileAnketaContainer 

      />
      <AddPostContainer />
      <ul>{post}</ul> 
     
      </div>)
    }

  
}


 const mapStateToProps = (state) => {
    return {
      currentUser: state.signupPage.currentUser,
      posts: state.profilePage.posts,
      status: state.profilePage.status,
      livingPlace:state.profilePage.livingPlace,
      profileImageSrc:state.profilePage.profileImageSrc,
      date: state.profilePage.date,
      publicName:state.profilePage.publicName,
      postsIsFetching: state.profilePage.postsIsFetching,
      profileIsFetching: state.profilePage.profileIsFetching,
      profileId:state.profilePage.profileId
      
    }
  }
        

  
const ProfileContainer = connect(mapStateToProps, {
   onAddPosts, onDeletePostById,getPostsByUserId,getProfileFetch,getProfileByUserId,getPhotoByUserId
})(Profile);

export default ProfileContainer;

