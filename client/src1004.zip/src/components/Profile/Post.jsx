import s from './Post.module.css';
import {useState} from 'react'


function Post(props) {
let [readMoreState,setReadMoreState]=useState(true)
  //let background= `background-image:url('${props.postImageSrc}')`
  let date=props.date
    date = date.substr(0, 10)
    
  function ReadMoreFoo() {
    if (readMoreState) { setReadMoreState(false) } else { setReadMoreState(true) }
  }
  
    return (
      <div>
   <div class="blog-card">
    <div class="meta">
            <div class="photo" id={props.id} style={{backgroundImage:'url('+props.postImageSrc+')'}}></div>
      <ul class="details">
        <li class="author"><a href="#">{props.user}</a></li>
        <li class="date">{date}</li>
        <li class="tags">
          <ul>
            <li><a href="#">Learn</a></li>
            <li><a href="#">Code</a></li>
            <li><a href="#">HTML</a></li>
            <li><a href="#">CSS</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="description">
            <h1>{ props.postTitle}</h1>
      
            {readMoreState ? (<ReadMore ReadMoreFoo={ ()=>ReadMoreFoo()} postBody={ props.postBody}/>):(<Full ReadMoreFoo={ ()=>ReadMoreFoo()} postBody={ props.postBody}/>)}  
       
            
    </div>
  </div>
  </div>
  );
}
function ReadMore(props) {
  return ( <>
       <p class='descrtext'> {props.postBody}</p>
          <p class="read-more">
          <span onClick={()=>props.ReadMoreFoo()}>Read More</span>
            </p>
    </>)
}
function Full(props) {
  return (<> <p class='descrtextfull'> {props.postBody}</p>
    <p class="read-more">
          <span onClick={()=>props.ReadMoreFoo()}>Свернуть</span>
            </p>
     </>)
}


export default Post;