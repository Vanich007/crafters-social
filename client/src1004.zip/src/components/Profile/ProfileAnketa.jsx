import React, {useState,useEffect} from 'react';
import UploadImage from './UploadImage'
import s from './ProfileAnketa.module.css'
import { getProfileByUserId ,updateProfile, userProfileSend} from '../../utils/API/connectProfile'
import { connect } from 'react-redux'


export function ProfileAnketa({getProfileByUserId,userProfileSend,currentUser, profileId, profileImageSrc,
   date, status = 'No status', livingPlace, publicName,updateProfile }) {
  console.log('props profileId='+profileId)
  let [changeAvatar,toggleChangeAvatar]=useState(false)
  let [statusState, setStatusState] = useState(status)
  let [livingPlaceState, setLivingPlaceState] = useState(livingPlace)
  let [publicNameState, setPublicNameState] = useState(publicName)
  let [profileImageSrcState, setprofileImageSrcState] = useState(profileImageSrc)
  let [statusIsEditing, setStatusIsEditing] = useState(false)
  let [LivingPlaceIsEditing, setLivingPlaceIsEditing] = useState(false)
  let [publicNameIsEditing, setPublicNameIsEditing] = useState(false)

  useEffect(()=>setStatusState(status),[status])
  useEffect(()=>setLivingPlaceState(livingPlace),[livingPlace])
  useEffect(()=>setPublicNameState(publicName),[publicName])
  useEffect(()=>setprofileImageSrcState(profileImageSrc),[profileImageSrc])
  
  useEffect(()=>getProfileByUserId(currentUser._id),[])

  const handleChange = event => {
    switch (event.target.name) {
      case 'status': setStatusState(event.target.value); break
      case 'livingPlace': setLivingPlaceState(event.target.value); break
      case 'publicName': setPublicNameState(event.target.value); break
      
    }
  }
  
  const Blur = type => {
    //event.preventDefault()
    switch (type) {
      case 'status': setStatusIsEditing(false); break;
      case 'livingPlace': setLivingPlaceIsEditing(false); break;
      case 'publicName': setPublicNameIsEditing(false); break;
      
  }
      updateProfile(currentUser._id,{

      status: statusState,
      livingPlace: livingPlaceState,
      publicName: publicNameState,
      profileImageSrc:profileImageSrcState
    })
  }



  //console.log('statusState='+statusState)
  return (<div className={s.anketablock}>
   
    {changeAvatar?(<UploadImage userProfileSend={userProfileSend} profileId={profileId} currentUser={currentUser} status={ statusState}
      livingPlace={livingPlaceState} 
      publicName={publicNameState} />):''}

    {(profileImageSrc)?<img src={profileImageSrc}></img>:''}
    <button onClick={()=>toggleChangeAvatar(!changeAvatar)}>Изменить аватар</button>
    
    {statusIsEditing ? (<div className={s.enterdata}>
      <label>Статус </label>
      <input
        name='status'
        placeholder='Статус'
        value={statusState}
        onChange={handleChange}
        onBlur={()=>Blur('status')}
      />
    </div >) : (<div className={s.show} onClick={()=>setStatusIsEditing(true) }>
      <label>Статус </label><b>{statusState}</b></div>
        
    )}
       {LivingPlaceIsEditing ? (<div className={s.enterdata}>
        <label>Место жительства</label>
        <input
          name='livingPlace'
          placeholder='Место жительства'
          value={livingPlaceState}
        onChange={handleChange}
        onBlur={()=>Blur('livingPlace')}
          />
    </div >) : (<div className={s.show} onClick={() => setLivingPlaceIsEditing(true)}>
         <label>Место жительства </label><b>{livingPlaceState}</b></div>
      )}
    
      {publicNameIsEditing ? (<div className={s.enterdata}>
        <label>Имя пользователя</label>
        <input
          name='publicName'
          placeholder='Имя пользователя'
          value={publicNameState}
          onChange={handleChange}
         onBlur={()=>Blur('publicName')}
          />
    </div >) : (<div className={s.show} onClick={() => setPublicNameIsEditing(true)}>
         <label>Имя пользователя </label><b>{publicNameState}</b></div>
      )}
       
    

    </div>)
  
}


const mapStateToProps = (state) => {
  return {
    currentUser: state.signupPage.currentUser,
    
    status: state.profilePage.status,
    livingPlace:state.profilePage.livingPlace,
    profileImageSrc:state.profilePage.profileImageSrc,
    date: state.profilePage.date,
    publicName:state.profilePage.publicName,
    profileIsFetching: state.profilePage.profileIsFetching,
    profileId:state.profilePage.profileId
  }
}
      


const ProfileAnketaContainer = connect(mapStateToProps,
   {updateProfile,getProfileByUserId,userProfileSend})(ProfileAnketa);




export default ProfileAnketaContainer;