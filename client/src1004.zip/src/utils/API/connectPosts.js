import {onAddPosts, onGetPosts} from '../../reducers/profileReducer'

export const sendUserPost = post => {
    return dispatch => {
      return fetch("http://localhost:5000/api/posts", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Authorization':localStorage.token
        },
        body: JSON.stringify(post)
      })
        .then(resp => resp.json())
        .then(data => {
          //console.log('data after post send='+data.postBody)
          if (data.message) {
            
            //Тут прописываем логику
          } else {
           // localStorage.setItem("token", data.jwt)
           dispatch(onAddPosts(data))
          }
        })
      } 
}
  export const getPostsByUserId = userId => {
    return dispatch => {
      let url=  "http://localhost:5000/api/posts/"+userId
      console.log('url='+url)
      return fetch(url, {
        method: "GET",
        headers: {
          'Content-Type': 'application/json',
          'Authorization':localStorage.token
       }

      })
        .then(resp => resp.json())
        .then(data => {
          console.log('userPostSend data=',data)
          if (data.message) {
            
            console.error(data.message)
          } else {
           dispatch(onGetPosts(data))
          }
        })
      }
}