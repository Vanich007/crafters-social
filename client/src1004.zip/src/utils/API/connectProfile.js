import {onGetProfile} from '../../reducers/profileReducer'
import {onGetSearchedProfiles} from '../../reducers/usersReducer'
import {getPostsByUserId} from './connectPosts'


  export const searchProfileByKeyword = keyword => {
    return dispatch => {
      let url=  "http://localhost:5000/api/profile/?search="+keyword
      
      return fetch(url, {
        method: "GET",
        headers: {
          'Content-Type': 'application/json',

           Accept: 'application/json'
        }
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('searchProfileByKeyword data=',data)
          if (data.message) {
            
            console.error(data.message)
          } else {
            //console.log('returned profiles id='+data[0]._id)
           dispatch(onGetSearchedProfiles(data))
           //getPostsByUserId(data._id)
          }
        })
      }
}

  export const getProfileByUserId = userId => {
    return dispatch => {
      if (userId===undefined) return null
      let url=  "http://localhost:5000/api/profile/"+userId
      console.log('url='+url)
      return fetch(url, {
        method: "GET",
        headers: {
          'Content-Type': 'application/json',

           Accept: 'application/json'
        }
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('getProfileByUserId data=',data)
          if (data.message) {
            
            console.error(data.message)
          } else {
            console.log('returned profile id='+data._id)
           dispatch(onGetProfile(data))
           getPostsByUserId(data.user)
          }
        })
      }
}
  

export const updateProfile = (userId,user) => {
    return dispatch => {
      let url=  "http://localhost:5000/api/profile/"+userId
      //console.log('url='+url)
      return fetch(url, {
        method: "PATCH",
        headers: {
          'Content-Type': 'application/json',
          'Authorization':localStorage.token
        },
        body: JSON.stringify(user)
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('updatedProfile data=',data)
          if (data.message) {
            console.error(data.message)
            //Тут прописываем логику
          } else {
           
           dispatch(onGetProfile(data))
          }
        })
      } 
}

export function userProfileSend(file, currentUser) {
  return dispatch => {
    let url = "http://localhost:5000/api/profile/" + currentUser
    console.log(file)
    return fetch(url, {
      method: "PATCH",
      headers: {
        'Authorization': localStorage.token
      },
      body: file
    })
      .then(resp => resp.json())
      .then(data => {
        console.log('updProfile data=',data)
        if (data.message) {
          console.error(data.message)
          //Тут прописываем логику
        } else {
          // localStorage.setItem("token", data.jwt)
          dispatch(onGetProfile(data))
        }
      })
   
  }
}