import { onGetProjects,onAddProject,onDeleteProject,onUpdateProject } from '../../reducers/projectsReducer'

export const getProjectById = userId => {
    return dispatch => {
      let url=  "http://localhost:5000/api/projects/"+userId
      //console.log('url='+url)
      return fetch(url, {
        method: "GET",
        headers: {
          'Content-Type': 'application/json',
           Accept: 'application/json'
        }
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('getProjects data=',data)
          if (data.message) {
            console.error(data.message)
          } else {
           dispatch(onGetProjects(data))
          }
        })
      }
}

  export const getProjectByUserId = userId => {
    return dispatch => {
      if (!userId||userId==='undefined') return null
      let url=  "http://localhost:5000/api/projects/user/"+userId
      console.log('url='+url)
      return fetch(url, {
        method: "GET",
        headers: {
          'Content-Type': 'application/json',
           Accept: 'application/json'
        }
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('getProjects data=',data)
          if (data.message) {
            console.error(data.message)
          } else {
           dispatch(onGetProjects(data))
          }
        })
      }
}
  export const deleteProjectById = projectId => {
    return dispatch => {
      let url=  "http://localhost:5000/api/projects/"+projectId
      //console.log('url='+url)
      return fetch(url, {
        method: "DELETE",
        headers: {
          'Content-Type': 'application/json',
           Accept: 'application/json'
        }
      })
        .then(resp => resp.json())
        .then(data => {
          console.log('delete data=',data)
          if (data.message) {
            
            console.log(data.message)
          } else {dispatch(onDeleteProject(data.deleted))
          }
        })
      }
}

export function sendUserProject(project) {
  return dispatch => { 
    return fetch("http://localhost:5000/api/projects", {
      method: "POST",
      headers: {
        'Authorization': localStorage.token
      },
      body: project
    })
      .then(resp => resp.json())
      .then(data => {
        //console.log('updProfile data=',data)
        if (data.message) {
          console.error(data.message)
          //Тут прописываем логику
        } else {
          // localStorage.setItem("token", data.jwt)
          dispatch(onAddProject(data))
        }
      })
   
  }
}
export function updateUserProject(projectId,project) {
  return dispatch => { 
    const url="http://localhost:5000/api/projects/"+projectId
    return fetch(url, {
      method: "PATCH",
      headers: {
        'Authorization': localStorage.token
      },
      body: project
    })
      .then(resp => resp.json())
      .then(data => {
        //console.log('updProfile data=',data)
        if (data.message) {
          console.error(data.message)
          //Тут прописываем логику
        } else {
          // localStorage.setItem("token", data.jwt)
          dispatch(onUpdateProject(data))
        }
      })
   
  }
}
export function likeProjectById(id) {
  return dispatch => {
    let url = "http://localhost:5000/api/projects/like/" + id
    //console.log(file)
    return fetch(url, {
      method: "PATCH",
      headers: {
        'Authorization': localStorage.token
      }
      // ,
      // body: file
    })
      .then(resp => resp.json())
      .then(data => {
        console.log('updProject data=',data)
        if (data.message) {
          console.error(data.message)
          //Тут прописываем логику
        } else {
          // localStorage.setItem("token", data.jwt)
          dispatch(onUpdateProject(data))
        }
      })
   
  }
}
export function unlikeProjectById(id) {
  return dispatch => {
    let url = "http://localhost:5000/api/projects/unlike/" + id
    //console.log(file)
    return fetch(url, {
      method: "PATCH",
      headers: {
        'Authorization': localStorage.token
      }
      // ,
      // body: file
    })
      .then(resp => resp.json())
      .then(data => {
        console.log('updProject data=',data)
        if (data.message) {
          console.error(data.message)
          //Тут прописываем логику
        } else {
          // localStorage.setItem("token", data.jwt)
          dispatch(onUpdateProject(data))
        }
      })
   
  }
}