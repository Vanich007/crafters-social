import s from './preloader.module.css'
export default function Preloader()
{
    return (<div className={s.preloader}>

    <div>

        <div>

            <div>

                <div>

                    <div>

                        <div>

                            <div>

                                <div>

                                    <div></div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>)
}