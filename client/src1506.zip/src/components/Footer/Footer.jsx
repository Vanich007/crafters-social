import s from './Footer.module.css';


function Footer(props) {
  return <footer id='#footer'>
      
      
        <li>&copy;2021</li>
        <li>Автор проекта - Ремезов Иван</li>
        <li><a href="mailto:admin@craftersocial.com">admin@craftersocial.com</a></li>
      
      
      </footer>

}

export default Footer;