const errorHandler = require("../utils/errorHandler")
const Post = require('../models/Posts')
const Tag = require('../models/Tags')
const Profile=require('../models/Profile')
const Lenta = require('../models/Lenta')
const User = require('../models/User')
const ObjectId = require('mongodb').ObjectId;
//const lentaConrtoller=require('./lenta')

module.exports.createLenta = async function (user) {
    console.log('createLenta')
    const candidate=await User.findOne({email:user.email})
    if (candidate) {
    const id = candidate._id
    let o_id = new ObjectId(id);
    try {
      const newLenta = new Lenta({
        user: o_id,
        interestTags:[],
        readedPosts:[]
      })
      await newLenta.save()
      
    } catch (e) {
      console.error(e)
    }}
  }
//lastPost= await Post.findOne({user:req.user.id}).sort({date:-1})
module.exports.getPosts = async function (req, res) {
    const user=req.query.user
    if (searchString.length)  search = {  }
    let user=''
    if (req.query.user&&req.query.user!=='undefined')
    {
        const o_id = new ObjectId(req.query.user)
        search.user=o_id
    } 
    


    try {
        const lenta = await Lenta.find(search)
        const readedPosts=lenta.readedPosts.map(item => item._id)
        const interestTags = lenta.interestTags(item => item.tagBody)
        //найдем непрочитанные посты по интересующим тегам
        const postSearch= { _id: { $nin: readedPosts },postTags:{$in:interestTags} } 
        const Posts = await Post.find(postSearch)
        console.log(Posts.length)
        //найдем непрочитанные посты юзеров, на которых подписан            
        const profile = await Profile.findOne({    //req.params.id - id страницы со списком сообщений
                user:o_id
        })
    
        const postSearch= { _id: { $nin: readedPosts },user:{$in:profile.follow} } 
        const Posts2 = await Post.find(postSearch)
        console.log(Posts.length)
        

        res.status(200).json([...Posts2,...Posts])
        for (i of Posts) { createLentaReadedPosts(user, i._id) }
        
        
    } catch (e) {
        errorHandler(res,e)
    }
}




const createLentaReadedPosts = async function (user, post) {
    console.log('user, post=',user, post)
    let o_id = new ObjectId(user)
        const updated = {readedPosts:post}
        try {
            const updPost = await Post.updateOne(
                {user: o_id},
                { $push: updated }
                // ,  {new: true}
              )
    } catch (e) {
        errorHandler(res,e)
    }
}

module.exports.createLentaInterestTags = async function (user,tags) {
    console.log(`createLentaInterestTags=${tags}`)
    let o_id = new ObjectId(user)
       
                   
        
        const updated = {interestTags:tags}
        try {
            // const updProfile = await Profile.updateOne(
            //     {user: o_id},
            //     {$push: updated},
            //     {new: true}
            //   )
            const updPost = await Lenta.updateOne(
                {user: o_id},
                { $addToSet: updated }          //$pull: updated
                // ,  {new: true}
              )
    } catch (e) {
        console.error(e)
    }
}

